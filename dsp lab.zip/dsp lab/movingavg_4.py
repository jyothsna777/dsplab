import scipy.io
from matplotlib import pyplot as plt
from scipy.io import wavfile
import numpy as np
c=np.cos(2*np.pi*200/10000*np.arange(0,200))
N=1*np.random.rand(len(c))
y=c+N
z=np.zeros(len(y))
M=int(input("Enter order"))
print(y)
for n in range(0,len(y)):
	s=0.0
	q=[]
	for k in range(0,M):
		if n-k>=0:
			q.append(y[n-k])
			s=s+y[n-k]
	z[n]=s/M

print(y)
print(z)
plt.subplot(211)
plt.stem(y)
plt.subplot(212)
plt.stem(z)
plt.show()


