from matplotlib import pyplot as plt
import numpy as np
y=10*np.random.rand(10)
z=np.zeros(len(y))
M=int(input("Enter order"))
for n in range(0,len(y)):
	s=0.0
	q=[]
	for k in range(0,M):
		if n-k>=0:
			q.append(y[n-k])
			s=s+y[n-k]
	z[n]=s/M

print(y)
print(z)
plt.subplot(211)
plt.plot(y)
plt.subplot(212)
plt.plot(z)
plt.show()


