import matplotlib.pyplot as plt

X = [590,540,740,130,810,300,320,230,470,620,770,250]
Y = [340,356,345,546,561,472,377,875,668,527,448,448]

plt.scatter(X,Y)
plt.show()
